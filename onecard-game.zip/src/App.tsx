import React from 'react'
import OneCardGame from './OneCardGame'

function App() {
  return (
    <div style={{ padding: '20px' }}>
      <h1>One Card Game</h1>
      <OneCardGame />
    </div>
  )
}

export default App
