import React, { useState } from 'react';

type Suit = '♠' | '♥' | '♦' | '♣';
type Rank = 'A' | '2' | '3' | '4' | '5' | '6' | '7' | '8' | '9' | '10' | 'J' | 'Q' | 'K';
type Card = { suit?: Suit; rank?: Rank; joker?: 'black' | 'color' };

function createDeck(): Card[] {
  const suits: Suit[] = ['♠', '♥', '♦', '♣'];
  const ranks: Rank[] = ['A','2','3','4','5','6','7','8','9','10','J','Q','K'];
  const deck: Card[] = [];
  for (let suit of suits) {
    for (let rank of ranks) {
      deck.push({ suit, rank });
    }
  }
  deck.push({ joker: 'black' });
  deck.push({ joker: 'color' });
  return deck;
}

function shuffle(deck: Card[]): Card[] {
  return [...deck].sort(() => Math.random() - 0.5);
}

function OneCardGame() {
  const [deck, setDeck] = useState<Card[]>(shuffle(createDeck()));
  const [playerHand, setPlayerHand] = useState<Card[]>([]);
  const [opponentHand, setOpponentHand] = useState<Card[]>([]);
  const [pile, setPile] = useState<Card[]>([]);
  const [message, setMessage] = useState<string>('');

  const drawCard = (handSetter: React.Dispatch<React.SetStateAction<Card[]>>, count: number = 1) => {
    setDeck(prevDeck => {
      const drawn = prevDeck.slice(0, count);
      handSetter(prev => [...prev, ...drawn]);
      return prevDeck.slice(count);
    });
  };

  const playCard = (card: Card, isPlayer: boolean) => {
    setPile(prev => [card, ...prev]);
    if (isPlayer) {
      setPlayerHand(prev => prev.filter(c => c !== card));
      applySpecialRule(card, setOpponentHand);
      if (playerHand.length === 2) {
        setMessage('원카드!');
        setTimeout(() => setMessage(''), 2000);
      }
    } else {
      setOpponentHand(prev => prev.filter(c => c !== card));
      applySpecialRule(card, setPlayerHand);
    }
  };

  const applySpecialRule = (card: Card, opponentSetter: React.Dispatch<React.SetStateAction<Card[]>>) => {
    if (card.joker === 'black') {
      drawCard(opponentSetter, 5);
    } else if (card.joker === 'color') {
      drawCard(opponentSetter, 7);
    } else if (card.rank === '2') {
      drawCard(opponentSetter, 2);
    } else if (card.rank === 'A' && card.suit === '♠') {
      drawCard(opponentSetter, 5);
    } else if (card.rank === 'A') {
      drawCard(opponentSetter, 3);
    } else if (['J','Q','K'].includes(card.rank || '')) {
      drawCard(opponentSetter, 1);
    }
  };

  return (
    <div>
      <h2>One Card Game</h2>
      <p>{message}</p>
      <div>
        <h3>Opponent ({opponentHand.length} cards)</h3>
      </div>
      <div style={{ margin: '20px 0' }}>
        <h3>Center Pile</h3>
        {pile[0] ? (
          <span style={{ fontSize: '2em' }}>
            {pile[0].joker ? (pile[0].joker === 'black' ? '🃏 Black Joker' : '🃏 Color Joker') : `${pile[0].suit}${pile[0].rank}`}
          </span>
        ) : <p>No cards yet</p>}
      </div>
      <div>
        <h3>Your Hand</h3>
        <div>
          {playerHand.map((card, idx) => (
            <button key={idx} onClick={() => playCard(card, true)} style={{ margin: '5px', padding: '10px' }}>
              {card.joker ? (card.joker === 'black' ? '🃏 Black Joker' : '🃏 Color Joker') : `${card.suit}${card.rank}`}
            </button>
          ))}
        </div>
        <button onClick={() => drawCard(setPlayerHand)}>Draw</button>
      </div>
    </div>
  );
}

export default OneCardGame;
